#!/usr/bin/env python3
def main():
    a = "poetry run python -m brain_games.scripts.brain_games\nWelcome to the Brain Games!"
    print(a)

if __name__ == '__main__':
    main()
