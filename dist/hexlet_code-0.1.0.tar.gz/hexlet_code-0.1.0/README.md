### Hexlet tests and linter status:
[![Actions Status](https://github.com/sergei-tiutriumov/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/sergei-tiutriumov/python-project-49/actions)
<a href="https://codeclimate.com/github/sergei-tiutriumov/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/a77b152643371fbecfec/maintainability" /></a>
